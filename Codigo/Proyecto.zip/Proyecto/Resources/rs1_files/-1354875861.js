DealPly.queryServer(" ");
